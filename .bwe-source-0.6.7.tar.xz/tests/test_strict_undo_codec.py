"""Static safety regression: strict blockstate restore requires a Forge runtime test."""
from pathlib import Path
p=Path(__file__).resolve().parents[1]/"src/main/java/net/barttolo/bwe/WorldData.java"
s=p.read_text()
assert "if (parsed.isEmpty())" in s
assert "Unknown saved property" in s
assert "Invalid saved property type" in s
assert "throw new IllegalArgumentException" in s
assert "parsed.isPresent() ? state.setValue" not in s
assert "if (property != null) state = applyProperty" not in s
build=(Path(__file__).resolve().parents[1]/"src/main/java/net/barttolo/bwe/BuildEngine.java").read_text()
assert "WorldData.decode(b.before());" in build, "Preflight must decode every state before rollback"
assert build.index("WorldData.decode(b.before());") < build.index("undoRunning = job;"), "Preflight before undo job"
print("OK: rollback fail-closed ante propiedades desconocidas o invalidas (auditoria estatica)")
